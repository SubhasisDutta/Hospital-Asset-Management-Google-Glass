Stopwatch
=========

This sample inserts a live card to the left of the Glass clock that displays a
stopwatch. Tapping the live card presents a menu with one option:

- Stop: remove the stopwatch from the timeline

## Getting started

Check out our documentation to learn how to get started on
https://developers.google.com/glass/gdk/index

## Running the sample on Glass

You can use your IDE to compile and install the sample or use
[`adb`](https://developer.android.com/tools/help/adb.html)
on the command line:

    $ adb install -r StopwatchSample.apk

To start the sample, say "ok glass, start a stopwatch" from the Glass clock
screen or use the touch menu.
