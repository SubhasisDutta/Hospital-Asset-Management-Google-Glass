Google Mirror API's Quickstart for Java
========================

The documentation for this quickstart is maintained on developers.google.com.
Please see here for more information:
https://developers.google.com/glass/quickstart/java

## License
Code for this project is licensed under [APL 2.0](http://www.apache.org/licenses/LICENSE-2.0.html)
and content is licensed under the
[Creative Commons Attribution 3.0 License](http://creativecommons.org/licenses/by/3.0/).
