The Do-No-Evil License Version 1.0 ([DNE-1.0](http://www.noevils.org/licenses/donoevil-1.0.html))

_Copyright (c) 2013 Harry Y_

Permission is hereby granted to any person obtaining a copy of this software to deal in the software without restriction subject to the following conditions: "The software shall be used for good, not evil."

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED.
