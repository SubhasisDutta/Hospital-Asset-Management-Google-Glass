package com.gdkdemo.window.menu.common;


// temporary
public final class MenuDemoConstants
{
    // The name of the "extra" key for MenuDemo intent service.
    public static final String EXTRA_KEY_ACTION = "extra_action";

}
