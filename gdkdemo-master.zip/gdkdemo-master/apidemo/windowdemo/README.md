Glass Development Kit - Window Demos
=======

Collection of Sample GDK apps related to general Glassware UI.


## Live Card Menu Demo

Google Glass GDK developer doc shows how to create a menu for a live card.

* [Displaying Menus in Live Cards](https://developers.google.com/glass/develop/gdk/ui/live-card-menus)

In essence, you need to create an activity,
whose sole purpose is for dislaying/handling menus/user interactions for the live card.

Start the demo app via the following voice command:

    OK, Glass. Start Menu Demo.

_Blog Post:_ [Google GDK Live Card Menu Example](http://blog.glassdiary.com/post/70229015767/google-gdk-live-card-menu-example).

