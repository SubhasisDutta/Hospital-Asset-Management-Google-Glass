package com.gdkdemo.livecard2.common;


public final class Config
{
    private Config() {}

    // Log level.
    public static int LOGLEVEL = android.util.Log.VERBOSE;
    //static final int LOGLEVEL = android.util.Log.DEBUG;
    //static final int LOGLEVEL = android.util.Log.INFO;

}
