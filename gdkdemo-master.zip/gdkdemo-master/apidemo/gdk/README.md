Glass Development Kit - GDK Library
=======

Directory for GDK related libraries and assets.


## Why do I use `gdk.jar` directly?

This blog post of mine, [GDK Sneak Peak Revision 2 - List of API Changes as Relevant to GDK Demo Apps](http://blog.glassdiary.com/post/70419002255/google-glass-development-kit-sneak-peak-revision-2), contains explanation as to why I do that.

