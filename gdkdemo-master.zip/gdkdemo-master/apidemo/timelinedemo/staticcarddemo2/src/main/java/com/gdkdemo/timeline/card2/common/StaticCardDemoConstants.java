package com.gdkdemo.timeline.card2.common;


// temporary
public final class StaticCardDemoConstants
{
    // The name of the "extra" key for StaticCardDemo intent service.
    public static final String EXTRA_KEY_ACTION = "extra_action";
    // ...

}
