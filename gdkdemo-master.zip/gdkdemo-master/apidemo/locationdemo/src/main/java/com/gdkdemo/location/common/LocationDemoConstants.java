package com.gdkdemo.location.common;


// temporary
public final class LocationDemoConstants
{
    // The name of the "extra" key for LocationDemo intent service.
    public static final String EXTRA_KEY_ACTION = "extra_action";
    // ...

}
