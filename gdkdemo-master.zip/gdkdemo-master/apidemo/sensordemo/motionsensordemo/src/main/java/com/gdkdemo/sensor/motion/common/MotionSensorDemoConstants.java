package com.gdkdemo.sensor.motion.common;


// temporary
public final class MotionSensorDemoConstants
{
    // The name of the "extra" key for MotionSensorDemo intent service.
    public static final String EXTRA_KEY_ACTION = "extra_action";
    // ...

}
