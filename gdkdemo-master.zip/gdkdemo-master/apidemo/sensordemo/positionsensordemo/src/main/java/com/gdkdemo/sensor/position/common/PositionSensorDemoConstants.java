package com.gdkdemo.sensor.position.common;


// temporary
public final class PositionSensorDemoConstants
{
    // The name of the "extra" key for PositionSensorDemo intent service.
    public static final String EXTRA_KEY_ACTION = "extra_action";
    // ...

}
