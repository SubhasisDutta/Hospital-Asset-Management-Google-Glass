package com.gdkdemo.sensor.environmental.cp.data;


/**
 * DB related constants.
 */
public class DataConstants
{
    // GdkDemoSensorDemoContentProvider Authority.
    // public static final String AUTHORITY = "com.gdkdemo.sensor.environmental.cp";

    private DataConstants() {}

}
