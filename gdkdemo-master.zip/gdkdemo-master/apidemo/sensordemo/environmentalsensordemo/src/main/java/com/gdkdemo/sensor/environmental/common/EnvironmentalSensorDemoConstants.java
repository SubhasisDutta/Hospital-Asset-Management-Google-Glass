package com.gdkdemo.sensor.environmental.common;


// temporary
public final class EnvironmentalSensorDemoConstants
{
    // The name of the "extra" key for EnvironmentalSensorDemo intent service.
    public static final String EXTRA_KEY_ACTION = "extra_action";
    // ...

}
