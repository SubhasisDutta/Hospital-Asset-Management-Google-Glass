package com.gdkdemo.sensor.environmental.cp.core;


public final class Config
{
    // Log level.
    public static final int LOGLEVEL = android.util.Log.VERBOSE;
    //static final int LOGLEVEL = android.util.Log.DEBUG;
    //static final int LOGLEVEL = android.util.Log.INFO;

    // TBD:
    // Read config.xml ????
    // ...
    
    
    // (Note: config.xml can be easily modified by the user.
    //        whereas this class is at least compiled int byte code....)
    // ...
    
}
