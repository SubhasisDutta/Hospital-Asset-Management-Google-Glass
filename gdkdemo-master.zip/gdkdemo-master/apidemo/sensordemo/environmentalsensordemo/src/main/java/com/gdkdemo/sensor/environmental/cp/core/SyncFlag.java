package com.gdkdemo.sensor.environmental.cp.core;


// Temporary
public final class SyncFlag
{
    // public static final int FLAG_NOSYNC = 0x0;
    public static final int FLAG_LOCAL = 0x1;
    public static final int FLAG_REMOTE = 0x2;

    // Static constants only.
    private SyncFlag() {}

}
