package com.gdkdemo.sensor.environmental.cp.core;


public class CpConstants
{

    public static final String CALLER_IS_SYNCADAPTER = "caller_is_syncadapter";

    
}
