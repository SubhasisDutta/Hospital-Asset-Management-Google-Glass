package com.gdkdemo.livecard3.common;


// temporary
public final class LiveCardDemoConstants
{
    // The name of the "extra" key for LiveCardDemo intent service.
    public static final String EXTRA_KEY_ACTION = "extra_action";
    // ...

}
