package com.gdkdemo.gesture.common;


// temporary
public final class GestureDemoConstants
{
    // The name of the "extra" key for GestureDemo intent service.
    public static final String EXTRA_KEY_GESTURE_TYPE = "extra_gesture";

    // Intent type to open the GestureInfo activity.
    public static final String INTENT_GESTURE_INFO_OPEN = "com.gdkdemo.gesture.gestureinfo.OPEN";
    // ...

}
